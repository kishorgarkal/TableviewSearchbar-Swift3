//
//  ViewController.swift
//  KishorGarkalEmployee
//
//  Created by kishor on 11/11/17.
//  Copyright © 2017 kishor. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate{
    
    let EmployeeName = ["Hritik","Ranvir","Akshay","bipasha","deepika","Shahrukh","Varun"]
    let Designation = ["CEO","Senior Manager","Manager","Assistant Manager","Androd Developer","IOS Developer","JAVA Developer"]
    
    
    var filteredData = [String]()
    
    var isSearching = false
    
    @IBOutlet weak var searchBar: UISearchBar!

    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        searchBar.delegate = self
        searchBar.returnKeyType = UIReturnKeyType.done
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isSearching{
            return filteredData.count
        }
        return EmployeeName.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableview.dequeueReusableCell(withIdentifier: "employeeTableViewCell") as! employeeTableViewCell
        
       
        
        if isSearching{
            cell.EmpNameLbl.text = filteredData[indexPath.row]
        }else{
            cell.EmpNameLbl.text = EmployeeName[indexPath.row]
            cell.imgview.image = UIImage(named: EmployeeName[indexPath.row])
            cell.DesignationLbl.text = Designation[indexPath.row]
        }
        
        
        
        return cell
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text == nil || searchBar.text == ""{
            isSearching = false
            view.endEditing(true)
            tableview.reloadData()
        }else{
            isSearching = true
            filteredData = EmployeeName.filter({$0 == searchBar.text})
            tableview.reloadData()
        }
}
    
}

