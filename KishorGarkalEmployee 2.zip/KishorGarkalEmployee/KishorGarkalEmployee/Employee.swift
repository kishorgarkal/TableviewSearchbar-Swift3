//
//  Employee.swift
//  KishorGarkalEmployee
//
//  Created by kishor on 11/13/17.
//  Copyright © 2017 kishor. All rights reserved.
//

import Foundation

struct Employee {
    let type : String
    let maker : String
    let model : String
    let image : String
}


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


