//
//  employeeTableViewCell.swift
//  KishorGarkalEmployee
//
//  Created by kishor on 11/11/17.
//  Copyright © 2017 kishor. All rights reserved.
//

import UIKit

class employeeTableViewCell: UITableViewCell {
    @IBOutlet weak var imgview: UIImageView!

    @IBOutlet weak var DesignationLbl: UILabel!
    @IBOutlet weak var EmpNameLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
